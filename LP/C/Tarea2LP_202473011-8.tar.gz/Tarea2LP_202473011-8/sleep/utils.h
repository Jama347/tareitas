#ifndef UTILS_H
#define UTILS_H

// Función multiplataforma para pausar la ejecución
void pausa_ms(int milisegundos);

#endif // UTILS_H
