rol: 202473011-8
nombre: joaquin muñoz
version de python usada: 3.11.9
ejecutar el archivo con el archivo "estrofas.txt" en la misma carpeta que Juez.py